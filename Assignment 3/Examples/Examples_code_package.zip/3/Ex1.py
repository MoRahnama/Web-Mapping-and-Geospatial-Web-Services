#!C:\ms4w\Python\python

s = "Hello world"

print("Content-type: text/html")
print()
print("<html>")
print("<head>")
print("<title>My first CGI program</title>")
print("</head>")
print("<body>")
print(s)
print("</body>")
print("</html>")